/* ============================================================
   api.js - API 客户端（用户端 + 管理后台共用）
   所有业务数据通过 HTTP 接口与后端交互
   ============================================================ */
'use strict';

window.API = (function () {
  const BASE = '';
  let adminToken = localStorage.getItem('admin_token') || '';
  let userToken = localStorage.getItem('user_token') || '';

  /* ---------- 静态部署模式（GitHub Pages 无后端时使用） ----------
     静态包会附带 site.config.js 将其置为 true；服务端部署时无该文件，走真实接口。 */
  const STATIC_MODE = !!(window.SITE_CONFIG && window.SITE_CONFIG.static === true);

  /* 公开只读接口 -> 静态数据文件的映射 */
  const STATIC_DATA = {
    '/api/gifts': 'data/gifts.json',
    '/api/categories': 'data/categories.json',
    '/api/announcements': 'data/announcements.json'
  };

  const STATIC_LIMIT_TIP = '静态展示版不支持该操作，请部署服务端版本以使用完整功能。';

  /* 需要登录或写操作的接口在静态模式下统一拦截，避免向不存在的服务端发请求 */
  function rejectInStaticMode() {
    return Promise.reject(new Error(STATIC_LIMIT_TIP));
  }

  function headers(auth, extra) {
    const t = auth === 'admin' ? adminToken : (auth === 'user' ? userToken : '');
    const h = Object.assign({ 'Content-Type': 'application/json' }, extra || {});
    if (t) h['Authorization'] = 'Bearer ' + t;
    return h;
  }

  async function request(method, url, body, auth) {
    /* 静态模式：可读的分发到本地 JSON，其余操作明确拒绝 */
    if (STATIC_MODE) {
      const file = STATIC_DATA[url];
      if (method === 'GET' && file) {
        const resp = await fetch(file);
        if (!resp.ok) throw new Error('静态数据加载失败：' + file);
        return resp.json();
      }
      return rejectInStaticMode();
    }

    const opt = { method: method, headers: headers(auth) };
    if (body !== undefined) opt.body = JSON.stringify(body);
    const resp = await fetch(BASE + url, opt);
    let data = null;
    try { data = await resp.json(); }
    catch (e) { data = { ok: false, error: '响应解析失败' }; }
    if (!resp.ok) {
      const err = new Error((data && data.error) || ('请求失败 ' + resp.status));
      err.status = resp.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  /* ---------- 用户端 ---------- */
  const api = {
    /* 当前用户信息（需登录） */
    me: function () { return request('GET', '/api/me', undefined, 'user'); },

    /* 礼品列表（上架商品） */
    gifts: function () { return request('GET', '/api/gifts'); },

    /* 礼品分类（公开，仅启用项，用户端导航与标签渲染用） */
    categories: function () { return request('GET', '/api/categories'); },

    /* 兑换礼品（需登录） */
    redeem: function (giftId, addressId) {
      return request('POST', '/api/redeem', { giftId: giftId, addressId: addressId }, 'user');
    },

    /* 我的订单（需登录） */
    orders: function () { return request('GET', '/api/orders', undefined, 'user'); },

    /* 积分明细（需登录） */
    transactions: function () { return request('GET', '/api/transactions', undefined, 'user'); },

    /* ---------- 用户端：收货地址管理 ---------- */
    addresses: function () { return request('GET', '/api/addresses', undefined, 'user'); },
    createAddress: function (label, detail) {
      return request('POST', '/api/addresses', { label: label, detail: detail }, 'user');
    },
    updateAddress: function (id, label, detail) {
      return request('PUT', '/api/addresses/' + id, { label: label, detail: detail }, 'user');
    },
    deleteAddress: function (id) {
      return request('DELETE', '/api/addresses/' + id, undefined, 'user');
    },

    /* ---------- 用户端：登录 / 登出 ---------- */
    userLogin: function (username, password) {
      return request('POST', '/api/user/login', { username: username, password: password });
    },
    userLogout: function () {
      userToken = '';
      localStorage.removeItem('user_token');
      return request('POST', '/api/logout', undefined, 'user');
    },
    getUserToken: function () { return userToken; },
    setUserToken: function (t) {
      userToken = t || '';
      if (t) localStorage.setItem('user_token', t);
      else localStorage.removeItem('user_token');
    },

    /* ---------- 管理后台：登录 ---------- */
    login: function (username, password) {
      return request('POST', '/api/login', { username: username, password: password });
    },

    logout: function () {
      adminToken = '';
      localStorage.removeItem('admin_token');
      return request('POST', '/api/logout', undefined, 'admin');
    },

    getToken: function () { return adminToken; },
    setToken: function (t) {
      adminToken = t || '';
      if (t) localStorage.setItem('admin_token', t);
      else localStorage.removeItem('admin_token');
    },

    /* ---------- 管理后台：看板 ---------- */
    adminMe: function () { return request('GET', '/api/admin/me', undefined, 'admin'); },
    dashboard: function () { return request('GET', '/api/admin/dashboard', undefined, 'admin'); },

    /* ---------- 管理后台：礼品 ---------- */
    adminGifts: function () { return request('GET', '/api/admin/gifts', undefined, 'admin'); },
    adminCreateGift: function (g) { return request('POST', '/api/admin/gifts', g, 'admin'); },
    adminUpdateGift: function (id, g) { return request('PUT', '/api/admin/gifts/' + id, g, 'admin'); },
    adminDeleteGift: function (id) { return request('DELETE', '/api/admin/gifts/' + id, undefined, 'admin'); },

    /* ---------- 首页公告（公开） ---------- */
    announcements: function () { return request('GET', '/api/announcements'); },

    /* ---------- 管理后台：礼品分类 ---------- */
    adminCategories: function () { return request('GET', '/api/admin/categories', undefined, 'admin'); },
    adminCreateCategory: function (c) { return request('POST', '/api/admin/categories', c, 'admin'); },
    adminUpdateCategory: function (id, patch) {
      return request('PUT', '/api/admin/categories/' + id, patch, 'admin');
    },
    adminDeleteCategory: function (id) {
      return request('DELETE', '/api/admin/categories/' + id, undefined, 'admin');
    },

    /* ---------- 管理后台：首页公告 ---------- */
    adminAnnouncements: function () { return request('GET', '/api/admin/announcements', undefined, 'admin'); },
    adminCreateAnnouncement: function (a) { return request('POST', '/api/admin/announcements', a, 'admin'); },
    adminUpdateAnnouncement: function (id, patch) {
      return request('PUT', '/api/admin/announcements/' + id, patch, 'admin');
    },
    adminDeleteAnnouncement: function (id) {
      return request('DELETE', '/api/admin/announcements/' + id, undefined, 'admin');
    },

    /* ---------- 管理后台：订单 ---------- */
    adminOrders: function (query) {
      const q = query || {};
      const params = new URLSearchParams();
      if (q.status && q.status !== 'all') params.set('status', q.status);
      if (q.kw) params.set('kw', q.kw);
      const qs = params.toString();
      return request('GET', '/api/admin/orders' + (qs ? '?' + qs : ''), undefined, 'admin');
    },
    adminOrderAction: function (id, action, extra) {
      return request('PUT', '/api/admin/orders/' + id, Object.assign({ action: action }, extra || {}), 'admin');
    },

    /* ---------- 管理后台：用户与积分 ---------- */
    adminUsers: function () { return request('GET', '/api/admin/users', undefined, 'admin'); },
    adminCreateUser: function (u) { return request('POST', '/api/admin/users', u, 'admin'); },
    adminUpdateUser: function (id, patch) { return request('PUT', '/api/admin/users/' + id, patch, 'admin'); },
    adminResetPassword: function (id, password) {
      return request('PUT', '/api/admin/users/' + id + '/password', { password: password }, 'admin');
    },
    adminDeleteUser: function (id) { return request('DELETE', '/api/admin/users/' + id, undefined, 'admin'); },
    adminAdjustPoints: function (id, amount, reason) {
      return request('PUT', '/api/admin/users/' + id + '/points', { amount: amount, reason: reason }, 'admin');
    },
    adminUserAddresses: function (id) {
      return request('GET', '/api/admin/users/' + id + '/addresses', undefined, 'admin');
    },
    adminCreateUserAddress: function (id, label, detail) {
      return request('POST', '/api/admin/users/' + id + '/addresses', { label: label, detail: detail }, 'admin');
    },
    adminUpdateUserAddress: function (id, addrId, label, detail) {
      return request('PUT', '/api/admin/users/' + id + '/addresses/' + addrId, { label: label, detail: detail }, 'admin');
    },
    adminDeleteUserAddress: function (id, addrId) {
      return request('DELETE', '/api/admin/users/' + id + '/addresses/' + addrId, undefined, 'admin');
    },

    /* ---------- 管理后台：图片上传 ---------- */
    adminUploadImage: function (dataUrl) {
      return request('POST', '/api/admin/uploads', { image: dataUrl }, 'admin');
    },

    /* ---------- 管理后台：账号管理（超管 + 系统管理员） ---------- */
    adminAccounts: function () { return request('GET', '/api/admin/accounts', undefined, 'admin'); },
    adminCreateAccount: function (a) { return request('POST', '/api/admin/accounts', a, 'admin'); },
    adminUpdateAccount: function (id, patch) {
      return request('PUT', '/api/admin/accounts/' + id, patch, 'admin');
    },
    adminResetAccountPassword: function (id, password) {
      return request('PUT', '/api/admin/accounts/' + id + '/password', { password: password }, 'admin');
    },
    adminDeleteAccount: function (id) {
      return request('DELETE', '/api/admin/accounts/' + id, undefined, 'admin');
    },
    adminUpdateSuper: function (patch) {
      return request('PUT', '/api/admin/super', patch, 'admin');
    },

    /* ---------- 运行模式 ---------- */
    /* true = 静态展示版（只读）；UI 层据此隐藏登录、兑换、后台等入口 */
    isStatic: function () { return STATIC_MODE; }
  };

  return api;
})();
