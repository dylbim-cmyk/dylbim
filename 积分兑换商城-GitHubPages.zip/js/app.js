/* ============================================================
   积分兑换商城 - 应用逻辑（动态版）
   数据源：后端 REST API（js/api.js）
   功能：分类筛选、排序、兑换（服务端原子处理）、
        订单追踪、积分明细、Toast 通知
   ============================================================ */

(function () {
  'use strict';

  /* ---------- 状态 ---------- */
  const state = {
    user: null,
    gifts: [],
    orders: [],
    currentCat: 'all',
    currentSort: 'default',
    search: '',
    activeTab: 'mall',
    orderFilter: 'all',
    selectedGift: null,
    pending: null,        // 触发登录前的待续操作：{intent, giftId}
    loading: true
  };

  /* ---------- DOM 引用 ---------- */
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  const el = {
    headerPoints: $('#headerPoints'),
    heroPoints: $('#heroPoints'),
    heroRedeemed: $('#heroRedeemed'),
    heroGifts: $('#heroGifts'),
    giftGrid: $('#giftGrid'),
    emptyState: $('#emptyState'),
    resultCount: $('#resultCount'),
    orderList: $('#orderList'),
    orderEmpty: $('#orderEmpty'),
    pointsPill: $('#pointsPill'),
    sortSelect: $('#sortSelect'),
    searchInput: $('#searchInput'),
    detailModal: $('#detailModal'),
    confirmModal: $('#confirmModal'),
    pointsModal: $('#pointsModal'),
    successModal: $('#successModal'),
    toastContainer: $('#toastContainer')
  };

  /* ---------- 工具函数 ---------- */
  function fmtPoints(n) {
    return Number(n).toLocaleString('zh-CN');
  }

  function getCatMeta(cat) {
    return window.CATEGORY_META[cat] || { label: '礼品', color: '#5C6470', bg: '#F1F2F4' };
  }

  /* ---------- 首页公告（后台可配置，动态生效） ---------- */
  /* 公告正文允许有限的强调类标签，渲染前统一清洗，杜绝脚本注入 */
  function sanitizeAnnHtml(html) {
    let s = String(html || '');
    s = s.replace(/<\s*\/?\s*(script|iframe|object|embed|link|style|meta)\b[^>]*>/gi, '');
    s = s.replace(/<([a-z]+)([^>]*)>/gi, function (m, tag, attrs) {
      if (!/^(strong|b|em|i|u|span|br|p)$/i.test(tag)) return '';
      const safeAttrs = attrs
        .replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '')
        .replace(/\s(?:href|src)\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
      return '<' + tag + safeAttrs + '>';
    });
    return s;
  }

  async function loadAnnouncements() {
    const box = $('#announcementBox');
    if (!box) return;
    try {
      const res = await window.API.announcements();
      const list = (res.announcements || []).filter(function (a) { return a.enabled !== false; });
      if (!list.length) { box.hidden = true; return; } /* 全部停用时隐藏整个 Banner */
      box.hidden = false;
      box.innerHTML = list.map(function (a) {
        return '<div class="promo-banner" role="region" aria-label="商城公告">' +
          '<span class="banner-tag">' + escapeHtml(a.tag) + '</span>' +
          '<p class="banner-text">' + sanitizeAnnHtml(a.content) + '</p>' +
          (a.linkText
            ? '<a href="' + escapeHtml(a.linkTarget || '#giftGrid') + '" class="banner-link"' +
              (a.linkTarget === '#giftGrid' ? ' data-nav="all"' : '') + '>' + escapeHtml(a.linkText) + '</a>'
            : '') +
          '</div>';
      }).join('');
    } catch (e) { /* 接口异常时保留静态默认公告 */ }
  }

  /* ---------- 分类（后台可配置，动态生效） ---------- */
  async function loadCategories() {
    try {
      const res = await window.API.categories();
      const cats = (res.categories || []).filter(function (c) { return c.enabled !== false; });
      if (!cats.length) return; /* 无数据时保留静态默认 */
      const meta = {};
      cats.forEach(function (c) { meta[c.id] = { label: c.name, color: c.color, bg: c.bg }; });
      window.CATEGORY_META = meta;
      /* 当前选中分类若已被停用/删除，回退到全部 */
      if (state.currentCat !== 'all' && !meta[state.currentCat]) state.currentCat = 'all';
      renderCategoryTabs(cats);
      renderNavCatMenu(cats);
    } catch (e) { /* 接口异常时保留静态默认 */ }
  }

  function renderCategoryTabs(cats) {
    const wrap = document.querySelector('.category-tabs');
    if (!wrap) return;
    const items = ['<button class="cat-btn' + (state.currentCat === 'all' ? ' active' : '') +
      '" role="tab" aria-selected="' + (state.currentCat === 'all') + '" data-cat="all">全部</button>'];
    cats.forEach(function (c) {
      const active = state.currentCat === c.id;
      items.push('<button class="cat-btn' + (active ? ' active' : '') +
        '" role="tab" aria-selected="' + active + '" data-cat="' + escapeHtml(c.id) + '">' + escapeHtml(c.name) + '</button>');
    });
    wrap.innerHTML = items.join('');
  }

  function renderNavCatMenu(cats) {
    const menu = document.querySelector('#navAllGoods .nav-dropdown');
    if (!menu) return;
    menu.innerHTML = '<a href="#mall" class="dropdown-item" role="menuitem" data-nav="all">全部商品</a>' +
      cats.map(function (c) {
        return '<a href="#mall" class="dropdown-item" role="menuitem" data-nav-cat="' + escapeHtml(c.id) + '">' + escapeHtml(c.name) + '</a>';
      }).join('');
  }

  function stockState(gift) {
    if (gift.stock === 0) return { cls: 'stock-out', text: '已兑完' };
    if (gift.stock <= gift.stockWarning) return { cls: 'stock-low', text: '仅剩 ' + gift.stock + ' 件' };
    return { cls: 'stock-ok', text: '库存充足' };
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
  }

  /* ---------- Toast ---------- */
  function toast(msg, type) {
    const t = document.createElement('div');
    t.className = 'toast toast-' + (type || 'info');
    t.textContent = msg;
    el.toastContainer.appendChild(t);
    setTimeout(function () {
      t.classList.add('hide');
      setTimeout(function () { t.remove(); }, 350);
    }, 2600);
  }

  /* ---------- 弹窗通用 ---------- */
  function openModal(modal) {
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    const closeBtn = modal.querySelector('.modal-close');
    if (closeBtn) closeBtn.focus();
  }

  function closeAllModals() {
    $$('.modal-backdrop').forEach(function (m) { m.hidden = true; });
    document.body.style.overflow = '';
    state.pending = null;
  }

  $$('.modal-backdrop').forEach(function (backdrop) {
    backdrop.addEventListener('click', function (e) {
      if (e.target === backdrop) closeAllModals();
    });
  });

  $$('.modal-close, [data-close-modal]').forEach(function (btn) {
    btn.addEventListener('click', function () { closeAllModals(); });
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      closeAllModals();
      closeAllDropdowns();
    }
  });

  /* ---------- 渲染：礼品网格 ---------- */
  function filteredGifts() {
    let list = state.gifts.slice();
    if (state.currentCat !== 'all') {
      list = list.filter(function (g) { return g.cat === state.currentCat; });
    }
    /* 关键词搜索：按名称 / 描述模糊匹配（前端过滤） */
    if (state.search) {
      const kw = state.search.toLowerCase();
      list = list.filter(function (g) {
        return (g.name || '').toLowerCase().indexOf(kw) !== -1 ||
               (g.desc || '').toLowerCase().indexOf(kw) !== -1;
      });
    }
    switch (state.currentSort) {
      case 'points-asc':
        list.sort(function (a, b) { return a.points - b.points; });
        break;
      case 'points-desc':
        list.sort(function (a, b) { return b.points - a.points; });
        break;
      case 'hot':
        list.sort(function (a, b) { return (b.hot ? 1 : 0) - (a.hot ? 1 : 0); });
        break;
      default:
        break;
    }
    return list;
  }

  /* 礼品展示图：有上传图片用图片，否则回退分类图标 */
  function giftMediaInner(g, meta) {
    if (g.image) {
      return '<img class="gift-img" src="' + escapeHtml(g.image) + '" alt="' + escapeHtml(g.name) + '" loading="lazy">';
    }
    return '<div class="gift-icon" style="background:' + meta.bg + ';color:' + meta.color + ';">' + (window.ICONS[g.icon] || window.ICONS.gift) + '</div>';
  }

  function renderGifts() {
    const list = filteredGifts();
    el.resultCount.textContent = '共 ' + list.length + ' 件礼品';

    if (list.length === 0) {
      el.giftGrid.innerHTML = '';
      el.emptyState.hidden = false;
      return;
    }
    el.emptyState.hidden = true;

    el.giftGrid.innerHTML = list.map(function (g) {
      const meta = getCatMeta(g.cat);
      const stock = stockState(g);
      const soldOut = g.stock === 0;
      const badges = [];
      if (g.hot && !soldOut) badges.push('<span class="gift-badge badge-hot">热门</span>');
      if (g.stock > 0 && g.stock <= g.stockWarning) badges.push('<span class="gift-badge badge-low">库存紧张</span>');

      return '' +
        '<article class="gift-card' + (soldOut ? ' sold-out' : '') + '" data-id="' + g.id + '" tabindex="0" role="button" aria-label="' + escapeHtml(g.name) + '，' + fmtPoints(g.points) + '积分">' +
        '  <div class="gift-media">' +
        '    ' + giftMediaInner(g, meta) +
        (badges.join('')) +
        (soldOut ? '<span class="sold-out-tag">已兑完</span>' : '') +
        '  </div>' +
        '  <div class="gift-body">' +
        '    <span class="gift-cat">' + meta.label + '</span>' +
        '    <h3 class="gift-name">' + escapeHtml(g.name) + '</h3>' +
        '    <div class="gift-footer">' +
        '      <span class="gift-points">' + fmtPoints(g.points) + ' <small>积分</small></span>' +
        '      <span class="gift-stock ' + stock.cls + '">' + stock.text + '</span>' +
        '    </div>' +
        '  </div>' +
        '</article>';
    }).join('');

    $$('.gift-card').forEach(function (card) {
      card.addEventListener('click', function () { openDetail(card.dataset.id); });
      card.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openDetail(card.dataset.id);
        }
      });
    });
  }

  /* ---------- 分类 / 排序 ---------- */
  /* 分类标签为动态渲染，采用事件委托 */
  document.querySelector('.category-tabs').addEventListener('click', function (e) {
    const btn = e.target.closest('.cat-btn');
    if (!btn) return;
    this.querySelectorAll('.cat-btn').forEach(function (b) {
      b.classList.remove('active');
      b.setAttribute('aria-selected', 'false');
    });
    btn.classList.add('active');
    btn.setAttribute('aria-selected', 'true');
    state.currentCat = btn.dataset.cat;
    renderGifts();
  });

  el.sortSelect.addEventListener('change', function () {
    state.currentSort = el.sortSelect.value;
    renderGifts();
  });

  /* 商品搜索：输入即时过滤 */
  if (el.searchInput) {
    el.searchInput.addEventListener('input', function () {
      state.search = el.searchInput.value.trim();
      renderGifts();
    });
  }

  /* ---------- 导航下拉菜单（全部商品二级分类 / 个人中心） ---------- */
  function closeDropdown(wrap) {
    if (!wrap) return;
    wrap.classList.remove('open');
    const trigger = wrap.querySelector('[aria-expanded]');
    if (trigger) trigger.setAttribute('aria-expanded', 'false');
  }

  function closeAllDropdowns() {
    $$('.nav-item-dropdown.open').forEach(closeDropdown);
  }

  function toggleDropdown(wrap) {
    if (!wrap) return;
    const willOpen = !wrap.classList.contains('open');
    closeAllDropdowns();
    if (willOpen) {
      wrap.classList.add('open');
      const trigger = wrap.querySelector('[aria-expanded]');
      if (trigger) trigger.setAttribute('aria-expanded', 'true');
    }
  }

  $$('.nav-dropdown-trigger, .user-center-btn').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      toggleDropdown(btn.closest('.nav-item-dropdown'));
    });
  });

  /* 点击下拉外部 / 按 Esc 关闭 */
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.nav-item-dropdown')) closeAllDropdowns();
  });

  /* ---------- 顶部导航扩展入口（全部商品 / 积分明细 / 收货地址） ---------- */
  /* 下拉菜单为动态渲染，采用事件委托 */
  document.addEventListener('click', function (e) {
    const navLink = e.target.closest('[data-nav]');
    const catLink = e.target.closest('[data-nav-cat]');
    const link = navLink || catLink;
    if (!link) return;
    e.preventDefault();
    if (navLink) {
      const action = navLink.dataset.nav;
      closeDropdown(navLink.closest('.nav-item-dropdown'));
      if (action === 'all') {
        const allBtn = document.querySelector('.cat-btn[data-cat="all"]');
        if (allBtn) allBtn.click();
        switchTab('mall');
        const toolbar = document.querySelector('.mall-toolbar');
        if (toolbar) toolbar.scrollIntoView({ behavior: 'smooth', block: 'start' });
      } else if (action === 'points') {
        if (!state.user) { openLoginModal({ intent: 'points' }); return; }
        renderPointsLog();
        openModal(el.pointsModal);
      } else if (action === 'address') {
        if (!state.user) { openLoginModal({ intent: 'address' }); return; }
        openAddressModal();
      }
      return;
    }
    /* 二级分类直达：切换分类并滚动到商品网格 */
    const cat = catLink.dataset.navCat;
    closeDropdown(catLink.closest('.nav-item-dropdown'));
    const catBtn = document.querySelector('.cat-btn[data-cat="' + cat + '"]');
    if (catBtn) catBtn.click();
    switchTab('mall');
    const grid = $('#giftGrid');
    if (grid) grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  /* ---------- 礼品详情 ---------- */
  function openDetail(id) {
    const g = state.gifts.find(function (x) { return x.id === id; });
    if (!g) return;
    state.selectedGift = g;

    const meta = getCatMeta(g.cat);
    const stock = stockState(g);
    const soldOut = g.stock === 0;

    $('#detailMedia').innerHTML = giftMediaInner(g, meta);

    $('#detailCat').textContent = meta.label;
    $('#detailTitle').textContent = g.name;
    $('#detailDesc').textContent = g.desc || '';
    $('#detailPoints').textContent = fmtPoints(g.points) + ' 积分';
    const stockEl = $('#detailStock');
    stockEl.textContent = stock.text;
    stockEl.className = 'meta-stock ' + stock.cls;
    $('#detailLimit').textContent = g.limit;

    /* 兑换须知：按分类区分实物（发货周期/退换）与虚拟（即时发放） */
    const notesEl = $('#detailNotes');
    if (notesEl) {
      const noteMap = {
        physical: [
          '确认兑换后订单进入待发货，将在 3-7 个工作日内寄出',
          '发货前可取消订单，积分将自动全额退回账户',
          '签收后如有质量问题，请 7 日内联系管理员处理'
        ]
      };
      const items = noteMap[g.cat] || [
        '确认兑换后权益即时发放至你的账户',
        '虚拟权益 / 卡券一经发放暂不支持退换',
        '如遇到账异常，请及时联系管理员核实'
      ];
      notesEl.innerHTML = items.map(function (t) { return '<li>' + t + '</li>'; }).join('');
    }

    const btn = $('#redeemBtn');
    if (window.API.isStatic()) {
      /* 静态展示版没有服务端，兑换流程不可用，直接禁用避免误导 */
      btn.disabled = true;
      btn.textContent = '演示版 · 暂不支持兑换';
    } else if (soldOut) {
      btn.disabled = true;
      btn.textContent = '已兑完';
    } else if (state.user && state.user.points < g.points) {
      btn.disabled = false;
      btn.textContent = '立即兑换（积分不足）';
    } else {
      btn.disabled = false;
      btn.textContent = '立即兑换';
    }

    openModal(el.detailModal);
  }

  /* ---------- 兑换确认 ---------- */
  function openConfirm(g) {
    if (!g || !state.user) return;

    if (state.user.points < g.points) {
      closeAllModals();
      toast('积分不足，还差 ' + fmtPoints(g.points - state.user.points) + ' 积分', 'error');
      return;
    }

    const before = state.user.points;
    const after = before - g.points;

    $('#confirmGiftName').textContent = g.name;
    $('#confirmGiftCat').textContent = getCatMeta(g.cat).label;
    $('#confirmGiftIcon').innerHTML = g.image
      ? '<img class="gift-img" src="' + escapeHtml(g.image) + '" alt="" style="width:48px;height:48px;border-radius:12px;">'
      : '<div class="gift-icon" style="background:' + getCatMeta(g.cat).bg + ';color:' + getCatMeta(g.cat).color + ';width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;">' +
        (window.ICONS[g.icon] || window.ICONS.gift) + '</div>';
    $('#confirmCost').textContent = fmtPoints(g.points) + ' 积分';
    $('#confirmBefore').textContent = fmtPoints(before) + ' 积分';
    $('#confirmAfter').textContent = fmtPoints(after) + ' 积分';

    const addrBlock = $('#addressBlock');
    if (g.cat === 'physical') {
      addrBlock.hidden = false;
      const sel = $('#addressSelect');
      const addrs = state.user.addresses || [];
      if (!addrs.length) {
        /* 无地址：显示空状态提示，引导用户新增 */
        sel.innerHTML = '<option value="">（暂无地址，请点击右侧「新增地址」）</option>';
      } else {
        sel.innerHTML = addrs.map(function (a) {
          return '<option value="' + a.id + '">' + escapeHtml(a.label) + ' · ' + escapeHtml(a.detail) + '</option>';
        }).join('');
      }
    } else {
      addrBlock.hidden = true;
    }

    $('#confirmTip').textContent = g.cat === 'physical'
      ? '确认后积分将扣减，订单进入待发货；取消订单积分自动退还。'
      : '确认后积分将立即扣减，虚拟权益即时发放。';

    closeAllModals();
    openModal(el.confirmModal);
  }

  $('#redeemBtn').addEventListener('click', function () {
    const g = state.selectedGift;
    if (!g) return;
    if (!state.user) {
      openLoginModal({ intent: 'redeem', giftId: g.id });
      return;
    }
    openConfirm(g);
  });

  /* ---------- 确认兑换（服务端处理） ---------- */
  $('#confirmBtn').addEventListener('click', async function () {
    const g = state.selectedGift;
    if (!g || !state.user) return;

    const btn = $('#confirmBtn');
    btn.disabled = true;
    btn.textContent = '兑换中…';

    try {
      const addressId = g.cat === 'physical' ? $('#addressSelect').value : '';
      if (g.cat === 'physical' && !addressId) {
        btn.disabled = false;
        btn.textContent = '确认兑换';
        toast('请先新增收货地址再兑换', 'error');
        openAddressModal();
        return;
      }
      const res = await window.API.redeem(g.id, addressId);

      // 更新本地状态（以服务端为准）
      state.user.points = res.user.points;
      state.user.redeemedThisMonth = res.user.redeemedThisMonth;
      const giftInState = state.gifts.find(function (x) { return x.id === g.id; });
      if (giftInState) giftInState.stock = res.gift.stock;
      state.orders.unshift(res.order);

      updatePointsUI();
      renderGifts();
      renderOrders();

      $('#successDesc').innerHTML =
        '「' + escapeHtml(res.order.name) + '」兑换成功' +
        (res.order.cat === 'physical' ? '，订单已进入待发货状态。' : '，权益已即时发放到你的账户。');
      closeAllModals();
      openModal(el.successModal);
    } catch (err) {
      closeAllModals();
      toast(err.message || '兑换失败，请稍后重试', 'error');
      renderGifts();
    } finally {
      btn.disabled = false;
      btn.textContent = '确认兑换';
    }
  });

  /* ---------- 收货地址管理 ---------- */
  let editingAddressId = null;

  /* 拉取最新地址列表并同步本地 state */
  async function refreshAddresses() {
    if (!state.user) return;
    try {
      const res = await window.API.addresses();
      state.user.addresses = res.addresses || [];
      /* 若兑换确认弹窗正打开且当前是实物礼品，同步刷新下拉 */
      if (!el.confirmModal.hidden && state.selectedGift && state.selectedGift.cat === 'physical') {
        const sel = $('#addressSelect');
        const addrs = state.user.addresses;
        if (!addrs.length) {
          sel.innerHTML = '<option value="">（暂无地址，请点击右侧「新增地址」）</option>';
        } else {
          sel.innerHTML = addrs.map(function (a) {
            return '<option value="' + a.id + '">' + escapeHtml(a.label) + ' · ' + escapeHtml(a.detail) + '</option>';
          }).join('');
        }
      }
    } catch (e) { /* 静默 */ }
  }

  function renderAddressList() {
    const list = state.user ? (state.user.addresses || []) : [];
    const box = $('#addressList');
    if (!list.length) {
      box.innerHTML = '<p class="address-empty">暂无地址，请在下方添加</p>';
      return;
    }
    box.innerHTML = list.map(function (a) {
      return '<div class="address-item">' +
        '<div class="address-item-info">' +
          '<span class="address-item-label">' + escapeHtml(a.label) + '</span>' +
          '<span class="address-item-detail">' + escapeHtml(a.detail) + '</span>' +
        '</div>' +
        '<div class="address-item-actions">' +
          '<button type="button" class="btn-link" data-addr-edit="' + a.id + '">编辑</button>' +
          '<button type="button" class="btn-link btn-danger-text" data-addr-del="' + a.id + '">删除</button>' +
        '</div>' +
      '</div>';
    }).join('');
    box.querySelectorAll('[data-addr-edit]').forEach(function (b) {
      b.addEventListener('click', function () { startEditAddress(b.dataset.addrEdit); });
    });
    box.querySelectorAll('[data-addr-del]').forEach(function (b) {
      b.addEventListener('click', function () { deleteAddress(b.dataset.addrDel); });
    });
  }

  function openAddressModal() {
    renderAddressList();
    resetAddressForm();
    openModal($('#addressModal'));
  }

  function resetAddressForm() {
    editingAddressId = null;
    $('#addressForm').reset();
    $('#addressCancelEdit').hidden = true;
    $('#addressSaveBtn').textContent = '保存地址';
  }

  function startEditAddress(id) {
    const a = (state.user.addresses || []).find(function (x) { return x.id === id; });
    if (!a) return;
    editingAddressId = id;
    $('#addressLabel').value = a.label || '';
    $('#addressDetail').value = a.detail || '';
    $('#addressCancelEdit').hidden = false;
    $('#addressSaveBtn').textContent = '更新地址';
    $('#addressLabel').focus();
  }

  async function deleteAddress(id) {
    if (!confirm('确定删除该收货地址吗？')) return;
    try {
      await window.API.deleteAddress(id);
      toast('地址已删除', 'success');
      await refreshAddresses();
      renderAddressList();
    } catch (err) {
      toast(err.message || '删除失败', 'error');
    }
  }

  /* 「新增地址」按钮：兑换确认弹窗内 + 地址管理弹窗内的入口 */
  $('#addAddressBtn').addEventListener('click', function () {
    openAddressModal();
  });

  $('#addressCancelEdit').addEventListener('click', function () {
    resetAddressForm();
  });

  $('#addressForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const label = $('#addressLabel').value.trim();
    const detail = $('#addressDetail').value.trim();
    if (!label || !detail) { toast('请填写地址标签与详细地址', 'error'); return; }
    const btn = $('#addressSaveBtn');
    const origin = btn.textContent;
    btn.disabled = true; btn.textContent = '保存中…';
    try {
      if (editingAddressId) {
        await window.API.updateAddress(editingAddressId, label, detail);
        toast('地址已更新', 'success');
      } else {
        await window.API.createAddress(label, detail);
        toast('地址已添加', 'success');
      }
      await refreshAddresses();
      renderAddressList();
      resetAddressForm();
    } catch (err) {
      toast(err.message || '保存失败', 'error');
    } finally {
      btn.disabled = false; btn.textContent = origin;
    }
  });

  /* ---------- 渲染：订单列表 ---------- */
  function filteredOrders() {
    if (state.orderFilter === 'all') return state.orders;
    return state.orders.filter(function (o) { return o.status === state.orderFilter; });
  }

  function renderOrders() {
    const list = filteredOrders();
    if (list.length === 0) {
      el.orderList.innerHTML = '';
      el.orderEmpty.hidden = false;
      return;
    }
    el.orderEmpty.hidden = true;

    el.orderList.innerHTML = list.map(function (o) {
      const meta = getCatMeta(o.cat);
      return '' +
        '<div class="order-card">' +
        '  <div class="order-icon" style="background:' + meta.bg + ';color:' + meta.color + ';">' + (window.ICONS[o.icon] || window.ICONS.gift) + '</div>' +
        '  <div class="order-info">' +
        '    <p class="order-name">' + escapeHtml(o.name) + '</p>' +
        '    <p class="order-meta">' + o.id + ' · ' + o.time + ' · ' + escapeHtml(o.note || '') + '</p>' +
        '  </div>' +
        '  <div class="order-right">' +
        '    <span class="order-points">-' + fmtPoints(o.points) + '</span>' +
        '    <span class="status-tag status-' + o.status + '">' + o.statusLabel + '</span>' +
        '  </div>' +
        '</div>';
    }).join('');
  }

  $$('.order-tab').forEach(function (btn) {
    btn.addEventListener('click', function () {
      $$('.order-tab').forEach(function (b) {
        b.classList.remove('active');
        b.setAttribute('aria-selected', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');
      state.orderFilter = btn.dataset.status;
      renderOrders();
    });
  });

  /* ---------- 渲染：积分明细（API） ---------- */
  async function renderPointsLog() {
    const res = await window.API.transactions().catch(function () {
      return { transactions: [], points: state.user ? state.user.points : 0 };
    });
    const list = res.transactions || [];

    $('#pointsModalBalance').textContent = fmtPoints(res.points !== undefined ? res.points : state.user.points) + ' 积分';

    $('#pointsList').innerHTML = list.slice(0, 30).map(function (item) {
      const inOut = item.amount > 0 ? 'in' : 'out';
      const sign = item.amount > 0 ? '+' : '';
      return '' +
        '<div class="points-item">' +
        '  <div class="points-item-info">' +
        '    <p class="points-item-title">' + escapeHtml(item.title) + '</p>' +
        '    <p class="points-item-time">' + item.time + '</p>' +
        '  </div>' +
        '  <span class="points-item-amount amount-' + inOut + '">' + sign + fmtPoints(item.amount) + '</span>' +
        '</div>';
    }).join('');
  }

  el.pointsPill.addEventListener('click', function () {
    if (!state.user) { openLoginModal({ intent: 'points' }); return; }
    renderPointsLog();
    openModal(el.pointsModal);
  });
  el.pointsPill.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      if (!state.user) { openLoginModal({ intent: 'points' }); return; }
      renderPointsLog();
      openModal(el.pointsModal);
    }
  });

  /* ---------- Tab 切换 ---------- */
  $$('[data-tab]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      const tab = link.dataset.tab;
      closeDropdown(link.closest('.nav-item-dropdown'));
      if (tab === 'orders' && !state.user) {
        openLoginModal({ intent: 'orders' });
        return;
      }
      switchTab(tab);
    });
  });

  function switchTab(tab) {
    state.activeTab = tab;
    $$('.nav-link').forEach(function (l) {
      l.classList.toggle('active', l.dataset.tab === tab);
    });
    const mall = $('#mall');
    const orders = $('#orders');
    mall.classList.toggle('active', tab === 'mall');
    orders.classList.toggle('active', tab === 'orders');
    mall.hidden = tab !== 'mall';
    orders.hidden = tab !== 'orders';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  $('[data-goto-orders]').addEventListener('click', function () {
    closeAllModals();
    switchTab('orders');
  });
  $('[data-goto-mall]').addEventListener('click', function () {
    switchTab('mall');
  });

  /* ---------- 积分数值更新 ---------- */
  function updatePointsUI() {
    const u = state.user;
    if (!u) return updatePointsUIAnon();
    el.headerPoints.textContent = fmtPoints(u.points);
    el.heroPoints.textContent = fmtPoints(u.points);
    el.heroRedeemed.textContent = (u.redeemedThisMonth || 0) + ' 件';
    el.heroGifts.textContent = state.gifts.filter(function (g) { return g.stock > 0; }).length + ' 件';
  }

  /* 未登录时的占位展示 */
  function updatePointsUIAnon() {
    el.headerPoints.textContent = '--';
    el.heroPoints.textContent = '--';
    el.heroRedeemed.textContent = '--';
    el.heroGifts.textContent = state.gifts.filter(function (g) { return g.stock > 0; }).length + ' 件';
  }

  /* ---------- 登录态用户栏（个人中心） ---------- */
  function applyUserBar() {
    const u = state.user;
    const loginBtn = $('#loginBtn');
    const center = $('#userCenter');
    if (u) {
      loginBtn.hidden = true;
      center.hidden = false;
      const name = u.name || '用户';
      $('#headerUserName').textContent = name;
      $('#userAvatar').textContent = name.slice(0, 1).toUpperCase();
      $('#userDropdownName').textContent = name;
    } else {
      loginBtn.hidden = false;
      center.hidden = true;
      closeDropdown(center);
    }
  }

  /* ---------- 登录弹窗（按需弹出） ---------- */
  function openLoginModal(pending) {
    /* 先关闭其余弹窗（礼品详情等），避免登录框被遮挡 */
    closeAllModals();
    state.pending = pending || null;

    /* 按触发场景给出明确的登录提示文案 */
    const sub = $('#loginSub');
    if (sub) {
      const map = {
        redeem: '该操作需要登录，请先登录后再兑换礼品',
        orders: '该操作需要登录，登录后即可查看我的兑换记录',
        points: '该操作需要登录，登录后即可查看积分明细',
        address: '该操作需要登录，登录后即可管理收货地址'
      };
      sub.textContent = (pending && map[pending.intent]) || '登录后即可使用积分兑换好礼';
    }

    $('#loginView').hidden = false;
    document.body.style.overflow = 'hidden';
    const u = $('#loginUsername');
    if (u) u.focus();
  }
  function closeLoginModal() {
    $('#loginView').hidden = true;
    document.body.style.overflow = '';
    state.pending = null;
  }

  /* 加载商城礼品（无需登录，默认可浏览） */
  async function loadGifts() {
    const res = await window.API.gifts();
    state.gifts = res.gifts;
    updatePointsUIAnon();
    renderGifts();
  }

  /* 加载当前用户会话数据（需登录） */
  async function loadUserSession() {
    const me = await window.API.me();
    state.user = me.user;
    const ordersRes = await window.API.orders().catch(function () { return { orders: [] }; });
    state.orders = ordersRes.orders;
  }

  /* ---------- 初始化 ---------- */
  async function init() {
    state.loading = true;
    // 商城默认可见，任何人都能浏览
    $('#appView').hidden = false;

    /* 静态展示版：给 body 加标记（样式据此隐藏登录 / 积分入口），并改写页脚为只读说明 */
    if (window.API.isStatic()) {
      document.body.classList.add('static-mode');
      const footerHint = $('.footer-hint');
      if (footerHint) {
        const adminLink = footerHint.querySelector('.footer-link');
        if (adminLink) adminLink.remove(); /* 静态版无后台，去掉入口避免误导 */
        footerHint.textContent = '版权所有 © ' + new Date().getFullYear() + ' dyl · 静态展示版（只读快照）';
      }
    }

    applyUserBar();
    updatePointsUIAnon();
    await loadAnnouncements(); /* 后台维护的首页公告（失败则保留静态默认） */
    await loadCategories(); /* 后台配置的分类（失败则保留静态默认） */
    await loadGifts();

    // 已存登录态则静默恢复，否则保持游客浏览态
    if (window.API.getUserToken()) {
      try {
        await loadUserSession();
        applyUserBar();
        updatePointsUI();
        renderOrders();
      } catch (e) {
        window.API.setUserToken(''); // 失效 token 清理
        applyUserBar();
      }
    }
    state.loading = false;
  }

  /* ---------- 用户登录 ---------- */
  $('#userLoginForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const username = $('#loginUsername').value.trim();
    const password = $('#loginPassword').value;
    if (!username || !password) { toast('请输入用户名和密码', 'error'); return; }
    const btn = this.querySelector('button[type="submit"]');
    const origin = btn.textContent;
    btn.disabled = true; btn.textContent = '登录中…';
    try {
      const res = await window.API.userLogin(username, password);
      window.API.setUserToken(res.token);
      state.user = res.user;
      const ordersRes = await window.API.orders().catch(function () { return { orders: [] }; });
      state.orders = ordersRes.orders;

      $('#loginPassword').value = '';
      applyUserBar();
      updatePointsUI();
      renderOrders();
      closeLoginModal();
      toast('登录成功，欢迎 ' + res.user.name, 'success');

      // 登录后继续执行被拦截的操作
      const pending = state.pending;
      state.pending = null;
      if (pending) {
        if (pending.intent === 'redeem') {
          const g = state.gifts.find(function (x) { return x.id === pending.giftId; });
          if (g) openConfirm(g);
        } else if (pending.intent === 'orders') {
          switchTab('orders');
        } else if (pending.intent === 'points') {
          renderPointsLog();
          openModal(el.pointsModal);
        } else if (pending.intent === 'address') {
          openAddressModal();
        }
      }
    } catch (err) {
      toast(err.message || '登录失败', 'error');
    } finally {
      btn.disabled = false; btn.textContent = origin;
    }
  });

  /* 头部"登录"按钮：打开登录弹窗（无后续操作） */
  $('#loginBtn').addEventListener('click', function () {
    openLoginModal(null);
  });

  /* ---------- 退出登录 ---------- */
  $('#logoutBtn').addEventListener('click', async function () {
    closeAllDropdowns();
    try { await window.API.userLogout(); } catch (e) { /* ignore */ }
    state.user = null;
    state.orders = [];
    state.pending = null;
    window.API.setUserToken('');
    applyUserBar();
    renderOrders();
    updatePointsUIAnon();
    toast('已退出登录', 'info');
  });

  document.addEventListener('DOMContentLoaded', init);
})();
